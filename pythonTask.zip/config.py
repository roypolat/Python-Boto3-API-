config = {
    "host": "0.0.0.0",
    "port": 8080,
    "aws_secret_access_key":"4sSAPf0MiTc8NLvCuut9B0Uln+2iKlYDgOoj9p62"
}
